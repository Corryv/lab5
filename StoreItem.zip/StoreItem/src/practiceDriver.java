import java.util.Scanner;

public class practiceDriver {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        // Initialize the pre-constructed inventory
        Inventory inventory = new Inventory();

        boolean running = true;

        while (running) {
            System.out.println("\n----- Welcome to Wilmington Quick Shop -----");
            System.out.println("      ================================");
            System.out.println("       Select from the options below");
            System.out.println("      ================================");
            System.out.println("1: Sell an item");
            System.out.println("2: Add an Item to Inventory");
            System.out.println("3: View Complete Inventory");
            System.out.println("4: Exit");
            System.out.print("Enter choice: ");

            int choice = getUserChoice();

            // Handle user choice
            switch (choice) {
                case 1: {
                    inventory.sell();
                    break;
                }
                case 2: {
                    boolean addingItems = true;
                    while (addingItems) {
                        inventory.displayCategoryInventory();

                        System.out.print("\nAdd to an existing item? (Y/N): ");
                        String choice4add = scanner.nextLine();

                        if (choice4add.equalsIgnoreCase("y")) {
                            inventory.add();
                        } else if(choice4add.equalsIgnoreCase("n")) {
                            inventory.addNew();
                        } else {
                            System.out.println("Invalid input");
                            continue; // Skip the "add another" question if input was invalid
                        }

                        // Ask if user wants to add another item (starting from category selection again)
                        System.out.print("\nWould you like to add another item? (Y/N): ");
                        String addAnother = scanner.nextLine();
                        if (addAnother.equalsIgnoreCase("n")) {
                            addingItems = false;
                            System.out.println("\nFinished adding items to inventory");

                            // Display updated inventory
                            System.out.println("\n=== UPDATED INVENTORY ===");
                            inventory.displayCompleteInventory();
                        } else if (!addAnother.equalsIgnoreCase("y")) {
                            System.out.println("Invalid input. Exiting item addition.");
                            addingItems = false;
                        }
                        // If "Y", the loop continues and goes back to category selection
                    }
                    break;
                }
                case 3: {
                    break;
                }
                case 4: {
                    running = false;
                    System.out.println("\nThank you for using Wilmington Quick Shop!");
                    break;
                }
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
        scanner.close();
    }

    /**
     * Helper method to safely get integer input from user
     * Handles NumberFormatException and clears buffer properly
     */
    private static int getUserChoice() {
        while (true) {
            try {
                String input = scanner.nextLine();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}