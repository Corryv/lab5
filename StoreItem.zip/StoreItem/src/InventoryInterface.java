public interface InventoryInterface {
    void displayCategoryInventory();
    void sell();
    void add();
    void addNew();
}