import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


// Inventory Interface implementation
public class Inventory implements InventoryInterface {

    // Initialized as ArrayList
    private static ArrayList<StoreItem> storeInventory = new ArrayList<>();
    private static ArrayList<StoreItem> cartInventory = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    // Construct inventory
    public Inventory() {
        storeInventory.add(new Fruit("wet", "puff", 69.994, 69, "09/05/2026", true, "red"));   // fruit
        storeInventory.add(new Vegetable("brockoli", "sun", 5.994, 5, "11/05/2025", false, "smooth", "green")); // veg
        storeInventory.add(new TV("Samyung", "fuzzy", 99.99, 6, 6, 56, "1080p", false)); // tv
        storeInventory.add(new HouseholdItem("spray", "timmy", 5.5, 2, "Wool")); // Household
    }

    // Display inventory
    public void displayCategoryInventory() {
        System.out.println("\n=== ADD TO INVENTORY ===");
        System.out.println("1. Food");
        System.out.println("2. Electronics");
        System.out.println("3. Clothing");
        System.out.println("4. Household");
        System.out.print("Enter category: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        String category = "";

        switch (choice) {
            case 1:
                category = "Food";
                break;
            case 2:
                category = "Electronic";
                break;
            case 3:
                category = "Clothing";
                break;
            case 4:
                category = "Household";
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }
        System.out.printf("Displaying %s Inventory%n", category);
        int index = 1;
        boolean foundItems = false;

        for (StoreItem item : storeInventory) {
            // Use instanceof with actual class types, not String
            boolean isCategory = switch (category) {
                case "Food" -> (item instanceof FoodItem);
                case "Electronic" -> (item instanceof ElectronicItem);
                case "Clothing" -> (item instanceof ClothingItem);
                case "Household" -> (item instanceof HouseholdItem);
                default -> false;
            };

            if (isCategory) {
                System.out.printf("%d. %s%n", index++, item.toString());
                foundItems = true;
            }

        }
        if (!foundItems) {
            System.out.println("No items found in this category.\n");
        }
    }


    public void add() {
        // Get item name
        System.out.print("Enter the item name: ");
        String itemToIncrease = scanner.nextLine().trim();

        // Get quantity with validation
        int quantity = 0;
        boolean validQuantity = false;
        while (!validQuantity) {
            System.out.print("Enter the quantity to add: ");
            String quantityInput = scanner.nextLine().trim();
            try {
                quantity = Integer.parseInt(quantityInput);
                if (quantity > 0) {
                    validQuantity = true;
                } else {
                    System.out.println("Quantity must be positive.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }

        // Check if item is in list
        boolean found = false;
        for (StoreItem i : storeInventory) {
            if (i.getName().equalsIgnoreCase(itemToIncrease)) {
                int oldQty = i.getQuantity();
                i.setQuantity(i.getQuantity() + quantity);
                found = true;
                System.out.println("\n✓ Quantity updated for " + i.getName());
                System.out.printf("   Old quantity: %d | New quantity: %d%n", oldQty, i.getQuantity());
                break;
            }
        }

        if (!found) {
            System.out.println("\n✗ Item '" + itemToIncrease + "' not found in inventory.");
            System.out.print("Would you like to add it as a new item? (Y/N): ");
            String choice = scanner.nextLine().trim();
            if (choice.equalsIgnoreCase("y")) {
                addNew(); // Add as new item
            } else {
                System.out.println("Skipping new item addition.");
            }
        }
    }

    public void addNew() {
        System.out.println("\n=== ADD NEW ITEM ===");
        System.out.println("Select category to add:");
        System.out.println("1. Food");
        System.out.println("2. Electronics");
        System.out.println("3. Clothing");
        System.out.println("4. Household");
        System.out.print("Enter choice: ");

        int type = scanner.nextInt();
        scanner.nextLine(); // Clear buffer

        switch (type) {
            case 1: { // Food
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter brand: ");
                String brand = scanner.nextLine();
                System.out.print("Enter price: ");
                double price = scanner.nextDouble();
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter expiration date (MM/DD/YYYY): ");
                String expiration = scanner.nextLine();
                System.out.print("Is it organic? (true/false): ");
                boolean organic = Boolean.parseBoolean(scanner.nextLine());

                FoodItem newItem = new FoodItem(name, brand, price, quantity, expiration, organic);
                storeInventory.add(newItem);
                System.out.println("\nAdded FoodItem: " + name);
                break;
            }

            case 2: { // Electronic
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter brand: ");
                String brand = scanner.nextLine();
                System.out.print("Enter price: ");
                double price = scanner.nextDouble();
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                System.out.print("Enter warranty length (months): ");
                int months = scanner.nextInt();
                scanner.nextLine();

                ElectronicItem newItem = new ElectronicItem(name, brand, price, quantity, months);
                storeInventory.add(newItem);
                System.out.println("\nAdded ElectronicItem: " + name);
                break;
            }

            case 3: { // Clothing
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter brand: ");
                String brand = scanner.nextLine();
                System.out.print("Enter price: ");
                double price = scanner.nextDouble();
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter size: ");
                String size = scanner.nextLine();
                System.out.print("Enter color: ");
                String color = scanner.nextLine();
                System.out.print("Enter material: ");
                String material = scanner.nextLine();

                ClothingItem newItem = new ClothingItem(name, brand, price, quantity, size, color, material);
                storeInventory.add(newItem);
                System.out.println("\nAdded ClothingItem: " + name);
                break;
            }

            case 4: { // Household
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter brand: ");
                String brand = scanner.nextLine();
                System.out.print("Enter price: ");
                double price = scanner.nextDouble();
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter material: ");
                String material = scanner.nextLine();

                HouseholdItem newItem = new HouseholdItem(name, brand, price, quantity, material);
                storeInventory.add(newItem);
                System.out.println("\nAdded HouseholdItem: " + name);
                break;
            }

            default:
                System.out.println("Invalid selection.");
                break;
        }

    }

    public void displayCompleteInventory() {
        if (storeInventory.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }

        int index = 1;
        for (StoreItem item : storeInventory) {
            System.out.printf("%d. %s%n", index++, item.toString());
        }
        System.out.println("=== END OF INVENTORY ===\n");
    }

    public void sell() {
        if (storeInventory.isEmpty()) {
            System.out.println("Inventory is empty. No items available for sale.");
            return;
        }

        // Array to store bought items (shopping cart)
        ArrayList<CartItem> cart = new ArrayList<>();
        boolean shopping = true;

        while (shopping) {
            // Display categories and get user selection
            System.out.println("\n=== SHOP BY CATEGORY ===");
            System.out.println("1. Food");
            System.out.println("2. Electronics");
            System.out.println("3. Clothing");
            System.out.println("4. Household");
            System.out.print("Select category to shop: ");

            int categoryChoice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            String category = "";
            switch (categoryChoice) {
                case 1: category = "Food"; break;
                case 2: category = "Electronic"; break;
                case 3: category = "Clothing"; break;
                case 4: category = "Household"; break;
                default:
                    System.out.println("Invalid category selection.");
                    continue;
            }

            // Display available items in the selected category
            System.out.printf("\n=== AVAILABLE %s ITEMS ===\n", category.toUpperCase());
            displayCategoryForSale(category);

            // Get item selection
            System.out.print("\nEnter the name of the item you want to purchase: ");
            String itemName = scanner.nextLine().trim();

            // Find the item
            StoreItem selectedItem = null;
            for (StoreItem item : storeInventory) {
                if (item.getName().equalsIgnoreCase(itemName)) {
                    boolean isCorrectCategory = switch (category) {
                        case "Food" -> (item instanceof FoodItem);
                        case "Electronic" -> (item instanceof ElectronicItem);
                        case "Clothing" -> (item instanceof ClothingItem);
                        case "Household" -> (item instanceof HouseholdItem);
                        default -> false;
                    };

                    if (isCorrectCategory && item.getQuantity() > 0) {
                        selectedItem = item;
                        break;
                    }
                }
            }

            if (selectedItem == null) {
                System.out.println("Item not found or out of stock in selected category.");
                continue;
            }

            // Get quantity
            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            if (quantity <= 0) {
                System.out.println("Quantity must be positive.");
                continue;
            }

            if (quantity > selectedItem.getQuantity()) {
                System.out.println("Insufficient stock. Only " + selectedItem.getQuantity() + " available.");
                continue;
            }

            // Add to cart
            cart.add(new CartItem(selectedItem, quantity));
            System.out.printf("Added %d x %s to cart\n", quantity, selectedItem.getName());

            // Ask if user wants to continue shopping
            System.out.print("\nWould you like to add another item to your order? (Y/N): ");
            String continueShopping = scanner.nextLine();
            if (continueShopping.equalsIgnoreCase("n")) {
                shopping = false;
            }
        }

        // Checkout process
        if (!cart.isEmpty()) {
            checkout(cart);
        } else {
            System.out.println("Cart is empty. No items purchased.");
        }
    }

    private void displayCategoryForSale(String category) {
        System.out.println("---------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-3s | %-20s | %-10s | %-8s | %-40s |\n", "No.", "Item Name", "Brand", "Price", "Details");
        System.out.println("---------------------------------------------------------------------------------------------------------");

        int index = 1;
        boolean foundItems = false;
        for (StoreItem item : storeInventory) {
            boolean isCategory = switch (category) {
                case "Food" -> (item instanceof FoodItem);
                case "Electronic" -> (item instanceof ElectronicItem);
                case "Clothing" -> (item instanceof ClothingItem);
                case "Household" -> (item instanceof HouseholdItem);
                default -> false;
            };

            if (isCategory && item.getQuantity() > 0) {
                // Use the item's toString method but remove the "Product Name:" and "Brand:" prefixes for cleaner display
                String details = getCleanDetails(item);
                System.out.printf("| %-3d | %-20s | %-10s | $%-7.2f | %-40s |\n",
                        index++, item.getName(), item.getBrand(), item.getPrice(), details);
                foundItems = true;
            }
        }

        if (!foundItems) {
            System.out.println("| No items available in this category.                                                          |");
        }
        System.out.println("---------------------------------------------------------------------------------------------------------");

        // Display return policy
        displayReturnPolicy(category);
    }

    private String getCleanDetails(StoreItem item) {
        String fullString = item.toString();
        // Remove the common prefixes for cleaner display
        String cleaned = fullString
                .replace("Product Name: ", "")
                .replace("Brand: ", "")
                .replace("Price: ", "")
                .replace("Quantity: ", "")
                .replace("$", "");

        // Extract just the details part (after brand and price)
        String[] parts = cleaned.split("\\s+", 4);
        if (parts.length >= 4) {
            return parts[3];
        }
        return cleaned;
    }

    private void displayReturnPolicy(String category) {
        System.out.println("\nReturn Policy for " + category + " items:");
        switch (category) {
            case "Food":
                System.out.println("  - Non-perishable: 30 days with receipt");
                System.out.println("  - Perishable: No returns, exchanges only for defective items");
                break;
            case "Electronic":
                System.out.println("  - 30-day return policy with original packaging");
                System.out.println("  - 1-year manufacturer warranty applies");
                break;
            case "Clothing":
                System.out.println("  - 60-day return policy with tags attached");
                System.out.println("  - Must be in original condition");
                break;
            case "Household":
                System.out.println("  - 90-day return policy for defective items");
                System.out.println("  - Must be in original packaging");
                break;
        }
    }

    private void checkout(ArrayList<CartItem> cart) {
        System.out.println("\n=== ORDER SUMMARY ===");
        System.out.println("----------------------------------------------------------------------");
        System.out.printf("| %-20s | %-10s | %-8s | %-10s |\n", "Item Name", "Quantity", "Price", "Subtotal");
        System.out.println("----------------------------------------------------------------------");

        double foodSubtotal = 0.0;
        double nonFoodSubtotal = 0.0;

        // Group items by category
        for (CartItem cartItem : cart) {
            StoreItem item = cartItem.getItem();
            int quantity = cartItem.getQuantity();
            double subtotal = item.getPrice() * quantity;

            System.out.printf("| %-20s | %-10d | $%-7.2f | $%-9.2f |\n",
                    item.getName(), quantity, item.getPrice(), subtotal);

            if (item instanceof FoodItem) {
                foodSubtotal += subtotal;
            } else {
                nonFoodSubtotal += subtotal;
            }
        }
        System.out.println("----------------------------------------------------------------------");

        // Calculate taxes (different rates for food vs non-food)
        final double FOOD_TAX_RATE = 0.02;  // 2% for food
        final double NON_FOOD_TAX_RATE = 0.07; // 7% for non-food

        double foodTax = foodSubtotal * FOOD_TAX_RATE;
        double nonFoodTax = nonFoodSubtotal * NON_FOOD_TAX_RATE;
        double totalTax = foodTax + nonFoodTax;
        double grandTotal = foodSubtotal + nonFoodSubtotal + totalTax;

        // Display breakdown
        System.out.printf("\nFood Items Subtotal: $%.2f\n", foodSubtotal);
        System.out.printf("Non-Food Items Subtotal: $%.2f\n", nonFoodSubtotal);
        System.out.printf("Food Tax (2%%): $%.2f\n", foodTax);
        System.out.printf("Non-Food Tax (7%%): $%.2f\n", nonFoodTax);
        System.out.printf("Total Tax: $%.2f\n", totalTax);
        System.out.printf("GRAND TOTAL: $%.2f\n", grandTotal);

        // Confirm checkout
        System.out.print("\nConfirm checkout? (Y/N): ");
        String confirm = scanner.nextLine();

        if (confirm.equalsIgnoreCase("y")) {
            // Process the sale
            for (CartItem cartItem : cart) {
                StoreItem item = cartItem.getItem();
                int quantity = cartItem.getQuantity();
                item.setQuantity(item.getQuantity() - quantity);
            }

            System.out.println("\nPurchase completed successfully!");
            System.out.println("Thank you for your purchase!");

            // Display updated inventory
            System.out.println("\n=== UPDATED INVENTORY ===");
            displayCompleteInventory();

            // Display return policies for purchased categories
            System.out.println("\n=== RETURN POLICIES FOR PURCHASED ITEMS ===");
            displayAllReturnPolicies(cart);

        } else {
            System.out.println("Purchase cancelled.");
        }
    }

    private void displayAllReturnPolicies(ArrayList<CartItem> cart) {
        Set<String> purchasedCategories = new HashSet<>();

        for (CartItem cartItem : cart) {
            StoreItem item = cartItem.getItem();
            if (item instanceof FoodItem) purchasedCategories.add("Food");
            else if (item instanceof ElectronicItem) purchasedCategories.add("Electronic");
            else if (item instanceof ClothingItem) purchasedCategories.add("Clothing");
            else if (item instanceof HouseholdItem) purchasedCategories.add("Household");
        }

        for (String category : purchasedCategories) {
            displayReturnPolicy(category);
            System.out.println();
        }
    }

    // Helper class to store items in shopping cart
    private static class CartItem {
        private StoreItem item;
        private int quantity;

        public CartItem(StoreItem item, int quantity) {
            this.item = item;
            this.quantity = quantity;
        }

        public StoreItem getItem() { return item; }
        public int getQuantity() { return quantity; }
    }

}

